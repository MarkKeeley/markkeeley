#include <iostream>
#include <chrono>
#include <vector>
#include <ctime>
#include <time.h>

#include <SDL2/SDL.h>

using namespace std;

const int windowWidth = 640;
const int windowHeight = 480;

int main( /*int argc, char* args[]*/ )
{
    //The window we'll be rendering to
    SDL_Window* window = nullptr;
    SDL_Renderer* renderer = nullptr;
    SDL_Event event;
    bool quit = false;
    auto start = chrono::steady_clock::now();
    auto end = chrono::steady_clock::now();
    auto deltaTime = end - start;
    vector<SDL_Rect> Rects;

    //Initialize SDL
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        cout << "SDL could not be initialized." << endl;
        cout << SDL_GetError() << endl;
        return 1;
    }

    //Create window
    window = SDL_CreateWindow( "SDL2 Framework", SDL_WINDOWPOS_UNDEFINED,
        SDL_WINDOWPOS_UNDEFINED, windowWidth,
        windowHeight, SDL_WINDOW_SHOWN );
    if( window == nullptr ) {
        cout << "Could not create Window" << endl;
        cout << SDL_GetError() << endl;
        SDL_Quit();
        return 1;
    }

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (renderer == nullptr) {
        SDL_DestroyWindow(window);
        cout << "Could not create Renderer" << endl;
        cout << SDL_GetError() << endl;
        SDL_Quit();
        return 1;
    }


    for (int i = 0; i <100; i++)
    {

        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);

        /* using nano-seconds instead of seconds */
        srand((time_t)ts.tv_nsec);

        int finalNum = rand()%(windowWidth-0)+0; // Generate the number, assign to variable.
        clock_gettime(CLOCK_MONOTONIC, &ts);

        srand((time_t)ts.tv_nsec);
        int finalNum2 = rand()%(windowHeight-0)+0;

        SDL_Rect tempRect{finalNum, finalNum2};
        tempRect.w = 20;
        tempRect.h = 20;
        Rects.push_back(tempRect);

    }


    //Main Loop
    while (!quit) {
        start = chrono::steady_clock::now();

        while ( SDL_PollEvent( &event ) )
            {
                if ( event.type == SDL_QUIT )
                    quit = true;

            }

        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderClear(renderer);

        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);

        for (int i = 0; i < Rects.size(); i++)
        {
            SDL_RenderFillRect(renderer, &Rects[i]);
        }


        SDL_RenderPresent(renderer);

        end = chrono::steady_clock::now();
        deltaTime = end - start;
        cout << chrono::duration <double, milli> (deltaTime).count() << " ms" << endl;

    }

    SDL_DestroyRenderer(renderer);
    //Destroy window
    SDL_DestroyWindow( window );

    //Quit SDL subsystems
    SDL_Quit();

}
