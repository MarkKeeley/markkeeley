package main

import (
	"fmt"
	"math/rand"
	"os"
	"time"

	"github.com/veandco/go-sdl2/sdl"
)

//Application main program object
type Application struct {
	renderer *sdl.Renderer
	window   *sdl.Window
	event    sdl.Event
	err      error
	running  bool
	boxes    []*sdl.Rect
}

// Setup initializes application
func (a *Application) Setup(title string, xposition int, yposition int,
	width int, height int, fullscreen bool) {
	// initialize SDL
	sdl.Init(sdl.INIT_EVERYTHING)

	var flags uint32 = sdl.WINDOW_SHOWN
	if fullscreen {
		flags = sdl.WINDOW_FULLSCREEN_DESKTOP
	}

	a.window, a.err = sdl.CreateWindow(title, xposition, yposition,
		width, height, flags)
	if a.err != nil {
		fmt.Fprintf(os.Stderr, "Failed to create window: %s\n", a.err)
		os.Exit(1)
	}
	a.renderer, a.err = sdl.CreateRenderer(a.window, -1, sdl.RENDERER_ACCELERATED)
	if a.err != nil {
		fmt.Fprintf(os.Stderr, "Failed to create renderer: %s\n", a.err)
		os.Exit(2)
	}

	//if the code got to here, everything seems to be working
	a.running = true

	for i := 0; i < 100; i++ {
		a.boxes = append(a.boxes, &sdl.Rect{})

		//rand.Intn640
		s1 := rand.NewSource(time.Now().UnixNano())
		r1 := rand.New(s1)

		a.boxes[i].X = int32(r1.Intn(windowWidth))
		a.boxes[i].Y = int32(r1.Intn(windowHeight))
		a.boxes[i].W = int32(20)
		a.boxes[i].H = int32(20)

		fmt.Println(a.boxes[i])
	}

}

// HandleEvents deals with window & keyboard events
func (a *Application) HandleEvents() {
	for a.event = sdl.PollEvent(); a.event != nil; a.event = sdl.PollEvent() {
		switch t := a.event.(type) {
		case *sdl.QuitEvent:
			a.running = false
		case *sdl.KeyDownEvent:
			if t.Keysym.Sym == sdl.K_ESCAPE {
				a.running = false
			}
		}
	}
}

// Update ...something
func (a *Application) Update() {

}

// Render clears window and draws
func (a *Application) Render() {
	a.renderer.SetDrawColor(255, 255, 255, 255)
	a.renderer.Clear()

	//a.renderer.SetDrawColor(100, 100, 100, 255)
	//a.renderer.FillRect(&sdl.Rect{0, 0, 200, 200})

	for i := range a.boxes {

		a.renderer.SetDrawColor(uint8(i)+50, uint8(i)+50, uint8(i)+50, 255)
		a.renderer.FillRect(a.boxes[i])
	}

	a.renderer.Present()
}

// Shutdown primarily deals with destroying sdl objects
func (a *Application) Shutdown() {
	a.window.Destroy()
	a.renderer.Destroy()
	sdl.Quit()
}
