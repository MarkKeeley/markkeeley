package main

import (
	"fmt"
	"time"

	"github.com/veandco/go-sdl2/sdl"
)

const (
	windowWidth  = 640
	windowHeight = 480
)

func main() {

	var app Application
	deltaTime := time.Now()
	//ticker := time.NewTicker(time.Second / 60)

	app.Setup("SDL2 Framework", sdl.WINDOWPOS_CENTERED, sdl.WINDOWPOS_CENTERED,
		windowWidth, windowHeight, false)

	//Main Loop
	for app.running {
		app.HandleEvents()
		app.Update()
		app.Render()

		fmt.Println(time.Since(deltaTime))
		deltaTime = time.Now()
		//<-ticker.C // limit framerate
	}

	//os.Exit(0)
	app.Shutdown()
}
